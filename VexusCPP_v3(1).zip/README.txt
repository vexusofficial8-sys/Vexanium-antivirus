VexusC++ v3 - standalone antivirus program (no terminal window)
===============================================================
1. Extract the WHOLE zip into a folder (keep all files together).
2. Double-click VexusCPP.hta - it opens as its own purple program window.

If Windows blocks it: right-click VexusCPP.hta > Properties > tick "Unblock" > OK
(or More info > Run anyway). .hta programs are often flagged because they run script code.

NEW IN v3
  * Quarantine Manager... button: lists everything in quarantine (threat name, when, and the
    original location it came from) with Restore / Delete per item and an Open Folder button.
  * Settings... button: change the whole window's color (8 presets or your own hex color).
    Your choice is remembered. Buttons always stay grey when off / green when on.

WHAT CHANGED IN v2
  * New logo (V + C++) in the header, window icon and VexusCPP.ico.
  * Full Scan crash fixes: files are now read one at a time instead of building giant lists,
    every file and folder is wrapped in error handling, internal errors are logged instead of
    killing the scan, and noisy system folders (WinSxS, Installer, servicing) are skipped.
  * Much faster: programs/scripts are hashed in batches by one hidden PowerShell call
    (falls back to certutil automatically if PowerShell is blocked).
  * More detection (see below), startup-entry check, threat log, scan time shown.

BUTTONS (grey = off, green = on)
  Quick Scan       Downloads, Documents, Desktop, Startup, AppData, Temp, Public, ProgramData + startup entries
  Full Scan        all fixed drives + startup entries (Windows folder skipped unless you turn that on)
  Custom Scan...   opens the Windows Explorer picker - choose any FILE or FOLDER
  Stop             cancel a running scan
  Real-Time Protection   checks NEW files in Downloads/Desktop/Startup/Temp/Public every ~4 seconds
  Heuristic Detection    turns the behaviour-style checks below on/off
  Auto-Quarantine        moves detections to %LOCALAPPDATA%\VexusCPP\Quarantine (off = report only)
  Scan Windows Folder    include C:\Windows in Full Scans (slower)
  Restore / Empty Quarantine

DETECTION
  * Hash signatures: SHA-256 and MD5 from signatures.txt (add your own known-bad hashes).
  * EICAR test file.
  * Heuristics: double extensions (invoice.pdf.exe), padded extensions, right-to-left-override
    filenames, programs disguised as documents/images (MZ header), suspicious scripts
    (encoded PowerShell, download-and-run, certutil/bitsadmin downloaders, ransomware-style
    shadow-copy deletion, security-tool disabling), autorun.inf worms on USB drives.
  * Startup check: Run/RunOnce registry entries pointing at Temp/Downloads/Public/AppData
    are reported as warnings (never deleted automatically) and the target file is scanned.
  Detections are also written to %LOCALAPPDATA%\VexusCPP\threats.log

TEST: save the standard EICAR test string into a .txt file in Downloads and run Quick Scan.
LIMITS: it only recognises hashes you put in signatures.txt plus the heuristics above, so it
is not a replacement for a maintained commercial antivirus. Heuristics can flag legitimate
admin scripts - check the log and use Restore Quarantine if needed.
